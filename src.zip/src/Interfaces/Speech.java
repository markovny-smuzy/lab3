package Interfaces;

//объект имеет свойство чего-то

public interface Speech {
    void Say();
    void NotSay();
}
