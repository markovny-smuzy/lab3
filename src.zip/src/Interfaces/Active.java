package Interfaces;

import Enums.Action;

//совершать действия

public interface Active {
    void Act(Action a);
}
