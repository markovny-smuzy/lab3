package Interfaces;

import Enums.Sign;

//персонаж(предмет) имеет признак

public interface Attribute {
    void Sig(Sign s);
}