package Interfaces;

public interface Gettable {
    String getName();
}
